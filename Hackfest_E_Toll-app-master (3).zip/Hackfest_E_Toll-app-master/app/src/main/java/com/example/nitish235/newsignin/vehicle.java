package com.example.nitish235.newsignin;

public class vehicle {
    private String vechicle_id;
    private String vechicle_num;
    public vehicle()
    {

    }

    public vehicle(String vechicle_id,String vechicle_num) {
        this.vechicle_id = vechicle_id;
        this.vechicle_num=vechicle_num;
    }

    public String getVechicle_id() {
        return vechicle_id;
    }
}

