# Hackfest_E_Toll-app

This app is part of out project of Hackfest19.
This app lets user select his journey and then pay.
I have used api of razorpay for payment purpose.
